from selenium.webdriver.common.by import By


class IndexLocate:
    welcome_title = (By.XPATH, '//div[@class="empty-state-block"]/h1')

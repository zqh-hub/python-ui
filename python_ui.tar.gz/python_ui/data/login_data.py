error_info_middle = [
    {"username": "admin", "password": "", "msg": "用户名或密码错误"},
    {"username": "", "password": "8161f26d2408481f8e92f31ad617e28d", "msg": "用户名或密码错误"},
    {"username": "admin", "password": "88888", "msg": "用户名或密码错误"},
    {"username": "", "password": "", "msg": "用户名或密码错误"}
]
success_login = [
    {"username": "admin", "password": "8161f26d2408481f8e92f31ad617e28d", "msg": "欢迎来到 Jenkins!"}
]

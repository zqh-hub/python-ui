import time
import unittest
from common import dir_config
from common.HTMLTestRunner import HTMLTestRunner
from case.test_login_case import LoginCase

suite = unittest.TestSuite()
loader = unittest.TestLoader()
suite.addTests(loader.loadTestsFromTestCase(LoginCase))
shot_time = time.strftime("%Y-%m-%d %H:%M", time.localtime(time.time()))
with open(dir_config.report_path + "{}_report.html".format(shot_time), "wb") as report:
    runner = HTMLTestRunner(stream=report, verbosity=2, title="我的report", description="哈哈")
    runner.run(suite)

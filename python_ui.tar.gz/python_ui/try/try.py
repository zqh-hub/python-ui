from selenium import webdriver
from selenium.webdriver.common.by import By
import time


class Try:
    username_input = (By.XPATH, '//*[@id="j_username"]')

    def login(self):
        safari = webdriver.Safari()
        safari.get("http://localhost:7070/login?from=%2F")
        safari.find_element(*self.username_input).send_keys("aaaa")

        time.sleep(10)
        safari.close()


if __name__ == '__main__':
    t = Try()
    t.login()

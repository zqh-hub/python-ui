from selenium import webdriver
from page.login_page import LoginPage
from page.index_page import IndexPage
from data import common_data, login_data
from ddt import ddt, data
import unittest
import warnings


@ddt
class LoginCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        warnings.simplefilter('ignore', ResourceWarning)
        cls.driver = webdriver.Chrome(common_data.driver)
        cls.login_page = LoginPage(cls.driver)
        cls.index_page = IndexPage(cls.driver)
        cls.driver.get("http://localhost:7070/login?from=%2F")
        cls.driver.maximize_window()

    def tearDown(self) -> None:
        self.driver.refresh()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.driver.close()

    @data(*login_data.success_login)
    def test_success_login(self, success_data):
        self.login_page.submit_login(success_data["username"], success_data["password"])
        self.assertEqual(self.index_page.def_get_welcome_title(), success_data["msg"])

    @data(*login_data.error_info_middle)
    def test_error_alert_middle(self, error_data):
        self.login_page.submit_login(error_data["username"], error_data["password"])
        self.assertEqual(self.login_page.def_get_username_password_error_alert_text(), error_data["msg"])


if __name__ == '__main__':
    unittest.main()
